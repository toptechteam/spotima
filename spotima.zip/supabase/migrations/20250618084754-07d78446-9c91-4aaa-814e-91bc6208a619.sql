
-- Ajouter la colonne photo_url à la table cards
ALTER TABLE public.cards ADD COLUMN photo_url TEXT;
