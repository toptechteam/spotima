import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { UploadZone } from "@/components/UploadZone";
import { Button } from "@/components/ui/button";
import { ArrowLeft, FileType2, Info } from "lucide-react";

const toolNames: Record<string, string> = {
  lucca: "Lucca",
  workday: "Workday",
  successfactors: "SAP SuccessFactors",
  excel: "Excel Générique",
};

const UploadPage = () => {
  const { toolId } = useParams<{ toolId: string }>();
  const navigate = useNavigate();
  const [sourceFile, setSourceFile] = useState<File | null>(null);
  const [targetFile, setTargetFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const toolName = toolId ? toolNames[toolId] : "l'outil sélectionné";

  const handleSourceFileUpload = (file: File) => {
    setSourceFile(file);
  };

  const handleTargetFileUpload = (file: File) => {
    setTargetFile(file);
  };

  const handleSubmit = () => {
    if (!sourceFile || !targetFile) {
      return;
    }

    setIsProcessing(true);
    
    // Simulate processing time
    setTimeout(() => {
      navigate(`/download/${toolId}`, { 
        state: { 
          originalFileName: sourceFile.name,
          targetFileName: targetFile.name,
          convertedFileName: `payfit_import_${new Date().toISOString().slice(0, 10)}.xlsx` 
        } 
      });
    }, 2000);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="ghost" 
            className="mb-8 text-gray-500 hover:text-gray-700"
            onClick={() => navigate("/")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la sélection d'outils
          </Button>

          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Importez vos fichiers
            </h1>
            <p className="text-gray-500">
              Notre outil va convertir automatiquement vos données en utilisant le fichier source et le modèle Payfit.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Zone d'upload fichier source */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                1. Fichier source {toolName}
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                Uploadez votre fichier source
              </p>
              <UploadZone 
                onFileUpload={handleSourceFileUpload}
                acceptedFileTypes=".xlsx,.csv,.xls"
              />
            </div>

            {/* Zone d'upload fichier cible Payfit */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                2. Fichier cible
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                Uploadez votre fichier cible Payfit à utiliser pour la conversion
              </p>
              <UploadZone 
                onFileUpload={handleTargetFileUpload}
                acceptedFileTypes=".xlsx,.xls"
              />
            </div>
          </div>

          {/* Bouton traiter centré entre les zones d'upload et l'aide */}
          <div className="text-center mt-8 mb-8">
            <Button 
              onClick={handleSubmit} 
              disabled={!sourceFile || !targetFile || isProcessing}
              className="w-full sm:w-auto px-8"
            >
              {isProcessing ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Traitement en cours...
                </>
              ) : (
                "Traiter les fichiers"
              )}
            </Button>
            {(!sourceFile || !targetFile) && (
              <p className="text-sm text-gray-500 mt-2">
                Veuillez uploader les deux fichiers pour continuer
              </p>
            )}
          </div>

          {/* Instructions pour télécharger le modèle Payfit */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-start gap-3">
              <Info className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-blue-800 mb-2">
                  Comment télécharger le modèle Payfit ?
                </h3>
                <ol className="text-sm text-blue-700 list-decimal list-inside space-y-1">
                  <li>Connectez-vous à votre espace Payfit</li>
                  <li>Dans le menu, cliquez sur "Absences et temps de travail"</li>
                  <li>Puis cliquez sur "Imports multiples"</li>
                  <li>Dans la section Import des variables de paie, cliquez sur l'icône "Importer" à droite</li>
                  <li>Puis téléchargez un modèle</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UploadPage;
