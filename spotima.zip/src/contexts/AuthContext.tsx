
import React, { createContext, useContext, useEffect, useState } from 'react';
import { apiClient } from '@/lib/api';

interface User {
  id: string;
  email: string;
  // Add other user properties as needed
}

interface Session {
  user: User;
  access_token: string;
  // Add other session properties as needed
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem('token');
        if (token) {
          const response = await apiClient.getSession();
          if (response.data) {
            setSession(response.data);
            setUser(response.data.user);
          }
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
        // Clear invalid token
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      const response = await apiClient.signIn(email, password);
      if (response.data.access_token) {
        localStorage.setItem('token', response.data.access_token);
        setSession({ user: response.data.user, access_token: response.data.access_token });
        setUser(response.data.user);
      }
      return { error: null };
    } catch (error: any) {
      return { error: error.response?.data?.message || 'An error occurred' };
    }
  };

  const signUp = async (email: string, password: string) => {
    try {
      await apiClient.signUp(email, password);
      return { error: null };
    } catch (error: any) {
      return { error: error.response?.data?.message || 'An error occurred' };
    }
  };

  const signOut = async () => {
    try {
      await apiClient.signOut();
      localStorage.removeItem('token');
      setSession(null);
      setUser(null);
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      await apiClient.resetPassword(email);
      return { error: null };
    } catch (error: any) {
      return { error: error.response?.data?.message || 'An error occurred' };
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      signIn,
      signUp,
      signOut,
      resetPassword,
      loading
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
