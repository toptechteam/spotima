
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ImageUpload } from '@/components/ImageUpload';
import { Building } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ToolData {
  id: string;
  name: string;
  description: string | null;
  photo_url: string | null;
  is_active: boolean | null;
  created_at: string;
  entreprises?: string[];
}

interface Entreprise {
  id: string;
  name: string;
}

interface ToolFormProps {
  isOpen: boolean;
  onClose: () => void;
  editingTool: ToolData | null;
  onToolSaved: () => void;
}

export function ToolForm({ isOpen, onClose, editingTool, onToolSaved }: ToolFormProps) {
  const [entreprises, setEntreprises] = useState<Entreprise[]>([]);
  const [selectedEntreprises, setSelectedEntreprises] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    photo_url: ''
  });
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      fetchEntreprises();
      if (editingTool) {
        setFormData({
          name: editingTool.name,
          description: editingTool.description || '',
          photo_url: editingTool.photo_url || ''
        });
        fetchToolEntreprises(editingTool.id);
      } else {
        resetForm();
      }
    }
  }, [isOpen, editingTool]);

  const fetchEntreprises = async () => {
    try {
      const { data, error } = await supabase
        .from('entreprises')
        .select('id, name')
        .order('name');

      if (error) throw error;
      setEntreprises(data || []);
    } catch (error) {
      console.error('Error fetching entreprises:', error);
    }
  };

  const fetchToolEntreprises = async (toolId: string) => {
    try {
      const { data, error } = await supabase
        .from('entreprise_card_assignments')
        .select('entreprise_id')
        .eq('card_id', toolId);

      if (error) throw error;
      setSelectedEntreprises(data?.map(assignment => assignment.entreprise_id) || []);
    } catch (error) {
      console.error('Error fetching tool entreprises:', error);
      setSelectedEntreprises([]);
    }
  };

  const updateToolEntreprises = async (toolId: string) => {
    try {
      // Supprimer toutes les assignations existantes
      await supabase
        .from('entreprise_card_assignments')
        .delete()
        .eq('card_id', toolId);

      // Ajouter les nouvelles assignations
      if (selectedEntreprises.length > 0) {
        const assignments = selectedEntreprises.map(entrepriseId => ({
          card_id: toolId,
          entreprise_id: entrepriseId
        }));

        const { error } = await supabase
          .from('entreprise_card_assignments')
          .insert(assignments);

        if (error) throw error;
      }
    } catch (error) {
      console.error('Error updating tool entreprises:', error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingTool) {
        const { error } = await supabase
          .from('cards')
          .update({
            name: formData.name,
            description: formData.description || null,
            photo_url: formData.photo_url || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingTool.id);

        if (error) throw error;

        // Mettre à jour les assignations d'entreprises
        await updateToolEntreprises(editingTool.id);

        toast({
          title: "Outil modifié",
          description: "Les informations de l'outil ont été mises à jour.",
        });
      } else {
        const { data: newTool, error } = await supabase
          .from('cards')
          .insert({
            name: formData.name,
            description: formData.description || null,
            photo_url: formData.photo_url || null
          })
          .select()
          .single();

        if (error) throw error;

        // Assigner les entreprises au nouvel outil
        if (newTool && selectedEntreprises.length > 0) {
          await updateToolEntreprises(newTool.id);
        }

        toast({
          title: "Outil créé",
          description: "Le nouvel outil a été créé avec succès.",
        });
      }

      onClose();
      onToolSaved();
    } catch (error) {
      console.error('Error saving tool:', error);
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de sauvegarder l'outil.",
      });
    }
  };

  const resetForm = () => {
    setFormData({ name: '', description: '', photo_url: '' });
    setSelectedEntreprises([]);
  };

  const handleImageChange = (imageUrl: string | null) => {
    setFormData({ ...formData, photo_url: imageUrl || '' });
  };

  const handleEntrepriseToggle = (entrepriseId: string, checked: boolean) => {
    if (checked) {
      setSelectedEntreprises(prev => [...prev, entrepriseId]);
    } else {
      setSelectedEntreprises(prev => prev.filter(id => id !== entrepriseId));
    }
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {editingTool ? 'Modifier l\'outil' : 'Nouvel outil'}
          </DialogTitle>
          <DialogDescription>
            {editingTool ? 'Modifiez les informations de l\'outil.' : 'Créez un nouvel outil.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nom *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
          </div>
          
          <div>
            <Label>Photo de l'outil</Label>
            <ImageUpload
              currentImageUrl={formData.photo_url}
              onImageChange={handleImageChange}
              placeholder="Photo de l'outil"
              size="md"
            />
          </div>

          <div>
            <Label className="text-base font-medium">Entreprises ayant accès à cet outil</Label>
            <p className="text-sm text-gray-500 mb-3">
              Sélectionnez les entreprises qui pourront utiliser cet outil
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-48 overflow-y-auto border rounded-lg p-4">
              {entreprises.map((entreprise) => (
                <div key={entreprise.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={`entreprise-${entreprise.id}`}
                    checked={selectedEntreprises.includes(entreprise.id)}
                    onCheckedChange={(checked) => 
                      handleEntrepriseToggle(entreprise.id, checked as boolean)
                    }
                  />
                  <Label 
                    htmlFor={`entreprise-${entreprise.id}`} 
                    className="text-sm font-normal cursor-pointer flex items-center gap-2"
                  >
                    <Building className="h-3 w-3" />
                    {entreprise.name}
                  </Label>
                </div>
              ))}
            </div>
            {selectedEntreprises.length > 0 && (
              <p className="text-xs text-blue-600 mt-2">
                {selectedEntreprises.length} entreprise(s) sélectionnée(s)
              </p>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={handleClose}>
              Annuler
            </Button>
            <Button type="submit">
              {editingTool ? 'Modifier' : 'Créer'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
